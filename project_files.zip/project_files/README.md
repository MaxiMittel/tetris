# Coop Tetris

## Install dependencies

Here is a list of the dependencies needed for the Python services.

```sh
pip3 install "Flask==1.1.4"
pip3 install flask-cors
pip3 install flask-script
pip3 install flask-pymongo
pip3 install python-dotenv
pip3 install "pymongo[srv]"
pip3 install flask-socketio
pip3 install simple-websocket
pip3 install pyjwt
```

To install dependencies for web-application `cd` into the `tetris-web` directory and run `npm install`.

## Run the project

```sh
python3 web-server/src/main.py

python3 directory-service/src/main.py 7777

python3 load-balancer/src/main.py 8000 lb-1
python3 load-balancer/src/main.py 8001 lb-1

python3 rest-api/src/main.py 9000 api-server-1
python3 rest-api/src/main.py 9001 api-server-2
python3 rest-api/src/main.py 9002 api-server-3

python3 game-server/src/main.py 10000 game-server-1
python3 game-server/src/main.py 10001 game-server-2
python3 game-server/src/main.py 10002 game-server-3
```